<div>
    <h1 class="text-center font-semibold text-gray-900 mb-8 leading-tight" style="font-size: 2.5rem;">Bienvenido al
        Dashboard de Usuarios</h1>

    <div class="mt-6" style="max-width: 960px; margin: 0 auto; display: flex; justify-content: space-between;">
        <div style="width: 45%;">
            <div style="max-width: 390px; margin: 0 auto;">
                <div class="bg-gray-800 rounded-lg shadow-md p-6">
                    <h2 class="text-2xl font-bold text-white mb-4 text-center">Registro de Usuario</h2>
                    <form class="flex flex-wrap" wire:submit.prevent="save">
                        <input type="text" wire:model="user.nombre"
                            class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duration-150 w-full md:w-[48%] mr-[2%]"
                            placeholder="Nombre" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['user.nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        <input type="text" wire:model="user.apellido"
                            class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duration-150 w-full md:w-[48%] ml-[2%]"
                            placeholder="Apellido" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['user.apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        <input type="email" wire:model="user.correo"
                            class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duración-150 w-full md:w-[48%] mr-[2%]"
                            placeholder="Correo" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['user.correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        <input type="number" wire:model="user.telefono"
                            class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duración-150 w-full md:w-[48%] ml-[2%]"
                            placeholder="Teléfono" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['user.telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        <input type="password" wire:model="user.contrasena"
                            class="bg-gray-700 text-gray-200 border-0 rounded-md p-2 mb-4 focus:bg-gray-600 focus:outline-none focus:ring-1 focus:ring-blue-500 transition ease-in-out duración-150 w-full md:w-[48%] mr-[2%]"
                            placeholder="Contraseña" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['user.contrasena'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        <button type="submit"
                            style="background-color: #4a90e2; color: white; font-weight: bold; padding: 0.5rem 1rem; border-radius: 0.25rem; margin-top: 1rem; display: block; margin-left: auto; margin-right: auto;">
                            Submit
                        </button>
                        <input type="checkbox" id="hide-message">
                        <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                                <label for="hide-message" class="close-btn">OK</label>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </form>
                </div>
            </div>
        </div>

        <div style="width: 50%;">
            <div class="flex justify-center">
                <div class="max-w-2xl mx-auto">
                    <div class="flex flex-col">
                        <div class="overflow-x-auto shadow-md sm:rounded-lg">
                            <div class="inline-block min-w-full align-middle">
                                <div class="overflow-hidden ">
                                    <table class="min-w-full divide-y divide-gray-200 table-fixed dark:divide-gray-700">
                                        <thead class="bg-gray-100 dark:bg-gray-700">
                                            <tr>

                                                <th scope="col"
                                                    class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                                    Nombre</th>
                                                <th scope="col"
                                                    class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                                    Apellido</th>
                                                <th scope="col"
                                                    class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                                    Telefono</th>
                                                <th scope="col"
                                                    class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                                    Email</th>
                                                <th scope="col"
                                                    class="py-3 px-6 text-xs font-medium tracking-wider text-left text-gray-700 uppercase dark:text-gray-400">
                                                    Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody
                                            class="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">

                                                    <td
                                                        class="py-4 px-6 text-sm font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                        <?php echo e($user->nombre); ?></td>
                                                    <td
                                                        class="py-4 px-6 text-sm font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                        <?php echo e($user->apellido); ?></td>
                                                    <td
                                                        class="py-4 px-6 text-sm font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                        <?php echo e($user->telefono); ?></td>
                                                    <td
                                                        class="py-4 px-6 text-sm font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                                        <?php echo e($user->correo); ?></td>
                                                    <td
                                                        class="py-4 px-6 text-sm font-medium text-right whitespace-nowrap">
                                                        <div style="display: flex; justify-content: space-between;">
                                                            <button type="submit"
                                                                style="background-color: #4a90e2; color: white; font-weight: bold; padding: 0.5rem 1rem; border-radius: 0.25rem; margin-top: 0.3rem;">
                                                                Editar
                                                            </button>
                                                            <button type="submit"
                                                                style="background-color: #ff0000; color: white; font-weight: bold; padding: 0.5rem 1rem; border-radius: 0.25rem; margin-top: 0.3rem; margin-left: 2px">
                                                                Eliminar
                                                            </button>
                                                        </div>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        </tbody>
                                    </table>
                                    <?php echo e($users->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .alert {
            width: 50%;
            margin: 0 auto;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .close-btn {
            display: inline-block;
            cursor: pointer;
            padding: 5px 10px;
            background-color: #337ab7;
            color: #fff;
            border-radius: 3px;
        }

        .close-btn:hover {
            background-color: #286090;
        }

        #hide-message {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }

        #hide-message:checked~.alert {
            display: none;
        }
    </style>
</div>
<?php /**PATH C:\laragon\www\Usuarios\resources\views/livewire/usuarios.blade.php ENDPATH**/ ?>