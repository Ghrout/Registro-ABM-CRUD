 <div>
     @livewire('usuarios')
 </div>
