<x-app-layout>
    <x-slot name="header">
    </x-slot>
    <div class="py-12">
        @livewire('livewire.usuarios')
    </div>
</x-app-layout>
